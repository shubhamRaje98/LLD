package org.example.Services;

public class PaymentService {
    public boolean processPayment(int i) {
        return true; // just a template
    }
}
