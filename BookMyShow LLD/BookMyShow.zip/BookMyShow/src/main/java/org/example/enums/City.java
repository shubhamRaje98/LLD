package org.example.enums;

public enum City {
    MUMBAI,
    DELHI,
    BANGLORE
}
