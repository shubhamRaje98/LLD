package org.example.enums;

public enum SeatTypeEnum {
    SILVER,
    GOLD,
    PLATINUM

}
