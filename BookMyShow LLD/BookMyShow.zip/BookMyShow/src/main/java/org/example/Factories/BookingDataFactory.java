package org.example.Factories;

import org.example.Services.MovieService;
import org.example.Services.TheaterService;
import org.example.entities.*;
import org.example.enums.City;

import java.time.LocalDateTime;
import java.time.Month;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class BookingDataFactory {

    public static List<Screen> createScreens() {
        TheaterFactory theaterFactory = new TheaterFactory();
        List<Screen> screens = new ArrayList<>();
        Screen screen1 = new Screen();
        screen1.setScreenId(1);
        screen1.setSeats(theaterFactory.createSeats());
        screens.add(screen1);
        return screens;
    }

    public static Show createShow(int showId, Movie movie, Screen screen, LocalDateTime showStartTime, LocalDateTime showEndTime) {
        Show show = new Show(showId, movie, screen, showStartTime, showEndTime, new ArrayList<>());
        return show;
    }

    public static List<Movie> createMovies(MovieService MovieService) {
        List<String> cast = new ArrayList<>();
        cast.add("Rebecca");
        cast.add("Shubham");
        Movie barbie = MovieFactory.createMovie(1, "BARBIE", 128, cast);
        Movie oppenheimer = MovieFactory.createMovie(2, "OPPENHEIMER", 180, cast);

        MovieService.addMovie(barbie, City.BANGLORE);
        MovieService.addMovie(barbie, City.DELHI);
        MovieService.addMovie(oppenheimer, City.BANGLORE);
        MovieService.addMovie(oppenheimer, City.DELHI);

        return Arrays.asList(barbie, oppenheimer);
    }

    public static void createTheaters(MovieService MovieService, TheaterService TheaterService) {
        Movie barbie = MovieService.getMovieByName("BARBIE");
        Movie oppenheimer = MovieService.getMovieByName("OPPENHEIMER");
        List<Screen> screens = createScreens();
        Theater inox = TheaterFactory.createTheater(1, "INOX", "Ghodbandar road", City.BANGLORE, screens);

        Theater pvr = TheaterFactory.createTheater(1, "INOX", "Ghodbandar road", City.BANGLORE, screens);

        TheaterService.addTheater(City.BANGLORE, inox);
        TheaterService.addTheater(City.DELHI, pvr);
    }

}